package fan.ENUMS;

public enum Side {
	LEFT, RIGHT
}
