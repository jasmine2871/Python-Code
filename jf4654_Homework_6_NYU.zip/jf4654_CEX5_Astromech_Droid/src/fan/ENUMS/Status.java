package fan.ENUMS;

public enum Status {
	ONLINE, OFFLINE
}
