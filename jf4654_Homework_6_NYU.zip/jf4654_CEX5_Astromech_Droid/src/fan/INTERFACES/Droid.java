package fan.INTERFACES;

public interface Droid {
	public abstract void displayDroid();
}
