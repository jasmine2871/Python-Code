package fan.INTERFACES;

public interface Displayable {
	public abstract void displayAllDroids();
}
